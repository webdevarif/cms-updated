"""
Cache module.
"""
