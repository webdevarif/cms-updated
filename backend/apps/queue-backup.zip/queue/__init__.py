"""
Queue module.
"""
