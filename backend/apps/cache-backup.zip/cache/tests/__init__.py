"""
Tests for cache module.
"""
