"""
Tests for queue module.
"""
